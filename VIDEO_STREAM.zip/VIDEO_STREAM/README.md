# Python-video-chat-app
This is a basic chat app in which client can send the video frames to the server and the server administrator can stream it.
<h3>Steps to Run:</h3>
Simply run server.py first (python3 server.py)<br>
And then run client.py (python3 client.py)
